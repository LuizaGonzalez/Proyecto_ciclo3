import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JOptionPane;
import java.util.Collections;
import java.util.Comparator;
import java.awt.Color;
import java.util.HashMap;
import java.util.Scanner;
/**
 * Ruta de seda con robots y tiendas que guardan montones de tengues, 
 * en donde cada robot se mueve para recolectarlas y tener una ganancia.
 * 
 * @author (Luiza Gonzalez - Camilo Leon ) 
 * @version (6 de septiembre del 2025)
 */
public class silkRoad{
    
    private static final String[] color = {"red", "yellow", "blue", "green", "magenta", "black", "darkGray", "lightGray", "orange", "cyan"};
    public int LocationStore;
    private int length;
    private int location;
    private int StartTenges;
    private int currentTenges;
    private int meters;
    private int totalProfit;
    private boolean lastOperationSuccess;
    private boolean isVisible;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    //spiral
    private int squareSize;
    private ArrayList<Rectangle> roadSegments;
    private int centerX;
    private int centerY;
    private HashMap<Integer, int[]> positions;
    
    //barra 
    private Rectangle fondo;
    private Rectangle relleno;
    private int ganancias;
    
    
    //ciclo1
    /**
     * Contructor de la clase silkBoard.
     * @param length longitud de la ruta seda.
     */
    public silkRoad(int length){
        this.length = length;
        this.location = 50;
        this.StartTenges = 0;
        this.currentTenges = 0;
        this.meters = 0;
        this.totalProfit = 0;
        stores =  new ArrayList<>();
        robots = new ArrayList<>();
        this.isVisible = false;
        this.lastOperationSuccess = true;
        this.squareSize = 40;
        roadSegments = new ArrayList<Rectangle>();
        this.centerX = 300;
        this.centerY = 300;
        positions = new HashMap<>();
        createSpiralRoad(length);
        // barra
        relleno = new Rectangle();
        fondo = new Rectangle();
        barraGanancia();
    }
    //ciclo2
    public silkRoad(int[][] days){
        this(calculateLength(days));
        
        for (int[] d : days){
            if (d[0] == 1){
                placeRobot(d[1]);
            }else if(d[0]==2){
                placeStore(d[1], d[2]);
            }
        }
    }
    
    /**
     * Registra la ganancia de un robot al visitar una tienda.
        */
    private void registerProfit(Robot robot, Store tienda) {
        int ganancia = tienda.getCurrentTenges(); // O el valor que se recoja
        robot.addProfit(ganancia);
    }

    /**
     * Registra que un robot salió de una tienda en cierta ubicación.
     */
    public void registerRobotExit(int location) {
        for (Store tienda : stores) {
            if (tienda.getLocationStore() == location) {
                tienda.markOutShop();
                break; // basta con encontrar una tienda
            }
        }
    }
    
    
    //consultar cuántas veces se vació cada tienda:
    public int[][] emptiedStores(){
        int[][] steam = new int[stores.size()][2];
        for(int i = 0; i < stores.size(); i++){
            Store s = stores.get(i);
            steam[i][0] = s.getLocationStore();
            steam[i][1] = s.contOutStore();
        }
        Arrays.sort(steam, (a, b) -> Integer.compare(a[0], b[0]));
        return steam; 
    }
    //consultar ganancias
    public int[][] profitPerMove(){
        int[][] robocop = new int[robots.size()][stores.size()];
        for(int i = 0; i < robots.size(); i++){
            Robot r = robots.get(i);
            robocop[i][0] = getLocationStore();
            ArrayList<Integer> movements = r.getProfitPerMove();
            for(int j = 0 ; j < movements.size(); j++){
                robocop[i][j + 1] = movements.get(j);
            }
        }
        Arrays.sort(robocop, (a, b) -> Integer.compare(a[0], b[0]));
        return robocop;
    }
    

 
    
    public int getLocationStore() {
        return LocationStore; 
    } 
    
    /**
     * Calcular logitud de la ruta de seda segun la ultima casa.
     * @days matriz que tiene los casos de entrada.
     * @return la logitud de la ruta de seda.
     */
    private static int calculateLength(int [][] days){
        int lastStore = 0;
        for (int[] d : days){
            int store = d[1];
            if (store > lastStore){
                lastStore = store;
            }
        }
        return lastStore + 1;
    }
    //Desde consola
    /**
     * leer entrada desde la consola
     * @return matriz de los days en donde se agregan robots o tiendas.
     */
    public static int[][] entryDays(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("");
        int n = scanner.nextInt();
        int[][] days = new int[n][];
        
        System.out.print("");
        for(int i =0 ;i< n;i++){
            int type = scanner.nextInt();
            
            if (type == 1){
                int ubicacion = scanner.nextInt();
                days[i] = new int[]{type, ubicacion};
            }else if (type == 2){
                int ubicacion = scanner.nextInt();
                int tenges = scanner.nextInt();
                days[i]= new int[]{type, ubicacion, tenges};
            }
        }
        scanner.close();
        return days;
    }
    //mini-ciclo2
    /**
     * metodo que mueve todos los robots segun la ganancia maxima
     */
    public void moveRobots(){
        for (Robot robit : robots){
            moveRobot(robit);
        }
    }
    
    /**
     * Método sobrecargado - Movimiento automático inteligente
     */
    public void moveRobot(Robot robot) {
        moveRobotMaxProfit(robot);
    }
    
    /**
     * metodo que calcula la maxima ganancia segun sus posibles opcciones.
     */
    private void moveRobotMaxProfit(Robot robit){
        int currentLocation = robit.getCurrentLocationRobot();
        int bestMove = currentLocation;
        int maxProfit = calculateProfit(currentLocation,currentLocation); 
        
        for (Store store : stores) {
            int storeLocation = store.getLocationStore();
            int profit = calculateProfit(currentLocation, storeLocation);
            if (profit > maxProfit) {
                maxProfit = profit;
                bestMove = storeLocation;
            }
        }
        
        if (bestMove != currentLocation) {
            int metersToMove = bestMove - currentLocation;
            moveRobot(currentLocation, metersToMove);
        }
    }
    
    /**
     * Calcula la ganancia potencial de moverse de una ubicación a otra
     */
    private int calculateProfit(int currentPos, int newPos) {
        int distance = Math.abs(newPos - currentPos);
        int storeProfit = 0;
        
        // Verifica si hay tienda en la nueva posición
        for (Store store : stores) {
            if (store.getLocationStore() == newPos) {
                storeProfit = store.getCurrentTenges();
                break;
            }
        }
        
        return storeProfit - distance;
    }
    //mini ciclo 3
    
    //hasta aqui ciclo2
    /**
     * Metodo para ubicar una tienda con su respectivo tenges. 
     * @param location posicion de la tienda.
     * @param tenges Son las monedas de Kazajistan.
     */
    public void placeStore(int location, int tenges){
        
        if (location < 0 || location > length){
            System.out.println("la locazion que deseas, esta por fuera del rango");
            lastOperationSuccess = false;
            
            if (isVisible) {
                JOptionPane.showMessageDialog(null, "Ubicación fuera de rango", "Error", JOptionPane.ERROR_MESSAGE);
            }
            return;
        }
        
        for (Store tienda : stores){
            if (tienda.getLocationStore() == location){
                System.out.println("Ya exixte una tienda en esta ubicacion");
                lastOperationSuccess = false;
                if (isVisible) {
                    JOptionPane.showMessageDialog(null, "Ubicación fuera de rango", "Error", JOptionPane.ERROR_MESSAGE);
                }
                return;
            }
        }
        
        Store newStore = new Store(location,tenges);
        stores.add(newStore);
        int[] pos = positions.get(location);
        if (pos != null){
            newStore.moveTo(pos[0],pos[1]);
        }
        barraGanancia();
        barraVisual();
        day();
        lastOperationSuccess = true;
        newStore.makeVisible();
        
    }

    /**
     * Metodo para eliminar una tienda dada su posicion.
     * @param location bposicion de la tienda.
     */
    public void removeStore(int location){
        for (int i = 0; i < stores.size(); i++) {
            Store tienda = stores.get(i);
            if (tienda.getLocationStore() == location){
                tienda.makeInvisible();
                stores.remove(tienda);
                barraGanancia();
                barraVisual();
                lastOperationSuccess = true;
                return;
            }
        }
    }
    
    /**
     * Metodo para ubicar un robot.
     * @param location posicion del robot.
     */
    public void placeRobot(int location){
        if (location<0 || location > length){
            System.out.println("la locazion que deseas, esta por fuera del rango");
            return;
        }
        
        for(Robot r : robots){
            if(r.getStartLocationRobot()== location ){
                System.out.println("Ya exixte un robot en esta ubicacion");
                return;
            }
        }
        
        Robot newRobot = new Robot(location);
        robots.add(newRobot);
        int[] pos = positions.get(location);
        if (pos != null){
            newRobot.moveTo(pos[0],pos[1]);
        }
        barraGanancia();
        barraVisual();
        day();
        lastOperationSuccess = true;
        newRobot.makeVisible();
    }
    
    /**
     * Metodo para eliminar un robot.
     * @param location posicion del robot.
     */
    public void removeRobot(int location){
        for (Robot r : robots){
            if (r.getCurrentLocationRobot() == location){
                r.makeInvisible();
                robots.remove(r);
                lastOperationSuccess = true;
                return;
            }
        }
    }
    
    /**
     * Metodo para mover un robot.
     * @param location posicion del robot.
     * @param meters metros que se movera el robot.
     */
    public void moveRobot(int location, int meters){
        
        Robot robotMove = null;
        for (Robot roro : robots){
            if(roro.getCurrentLocationRobot() == location){
                robotMove = roro;
                break;
            }
        }
        
        if (robotMove == null) {
            System.out.println("No se encontró robot en la ubicación: " + location);
            lastOperationSuccess = false;
            return;
        }
        
        int newLocation = location + meters;
            
        if (newLocation<0 ||newLocation >= length){
            
            JOptionPane.showMessageDialog(null,"No puedes mover el robot, ubicacion por fuera del rango","Error", JOptionPane.ERROR_MESSAGE);
            lastOperationSuccess = false;
            return;
        }
        
        for (Robot robit : robots){
            
            if (robit != robotMove &&  newLocation == robit.getCurrentLocationRobot()){
                
                JOptionPane.showMessageDialog(null,"Esta ubicación ya tiene un robot","Error", JOptionPane.ERROR_MESSAGE);
                lastOperationSuccess = false;
                return;
            }    
        }
    
        int[] newPosition = positions.get(newLocation);
        if (newPosition != null) {
            robotMove.moveTo(newPosition[1], newPosition[1]);
            robotMove.setCurrentLocationRobot(newLocation);
        }else {
            System.out.println("Error: No se encontró posición para location ");
        }
        lastOperationSuccess = true;
        //recolectarTENGUES
        collectVerifyRobotsStore(robotMove,newLocation);
        barraGanancia();
        barraVisual();
    }
    private void collectVerifyRobotsStore(Robot robot, int meters){
        int robotLocation = robot.getCurrentLocationRobot();
        for (Store store : stores) {
            if (store.getLocationStore() == robotLocation) {
                int Tenges = store.getCurrentTenges();
                int ganancia = Tenges - Math.abs(meters);
                
                if (ganancia > 0) {
                    store.setCurrentTenges(meters);
                    totalProfit += ganancia;
                }
            }
        }
    }
    
    /**
     * Cada vez que inicie un dia se va a crear una tienda o un robot entonces se reabastece
     */
    public void day() {
        resupplyStores();
    }
    
    /**
     * Metodo para reabastecer las tiendas.
     */
    public void resupplyStores(){
        if (stores.isEmpty()){
            System.out.println("No hay tiendas");
            return;
        }
        
        for (Store store : stores){
           store.setCurrentTenges(store.getTenges());
        }
        barraGanancia();
        barraVisual();
    }
    
    /**
     * Metodo para retornar los robots a sus posiciones iniciales.
     */
    public void returnRobots(){
       if (robots.isEmpty()){
           System.out.println("No hay robots");
           lastOperationSuccess = false;
           return;
       }
       
       for (Robot robit : robots){
           int startLocation = robit.getStartLocationRobot();
           int currentLocation = robit.getCurrentLocationRobot();
           if(currentLocation != startLocation){
               int[] newPosition = positions.get(startLocation);
               if (newPosition != null) {
                   robit.moveTo(newPosition[0], newPosition[1]);
                   robit.setCurrentLocationRobot(startLocation);
                }
           }
       }
       resupplyStores();
       totalProfit = 0;
       barraVisual();
       lastOperationSuccess = true;
    }
    
    /**
     * Metodo para reiniciar la ruta de seda: tiendas y robots como fueron adicionados.
     * 
     */
    public void reboot(){
        
        for (Robot robot : robots) {
            int startLocation = robot.getStartLocationRobot();
            int[] startPos = positions.get(startLocation);
            if (startPos != null) {
                robot.moveTo(startPos[0], startPos[1]);
                robot.setCurrentLocationRobot(startLocation);
            }
        }
        
        for (Store store : stores) {
            store.setCurrentTenges(store.getTenges());
        }
        // ganancias
        totalProfit = 0;
        barraVisual();
        lastOperationSuccess = true;
    }
    
    /**
     * Metodo para consultar las ganancias obtenidas.
     */
    public int profit(){
        return totalProfit - meters;
    }
    
      /**
     * Metodo para ordenar por localizacion de menor a mayor.[location,tenges]
     */
    public int[][] stores() {
        Collections.sort(stores, Comparator.comparingInt(Store::getLocationStore));
        int[][] result = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            Store store = stores.get(i);
            result[i][0] = store.getLocationStore();
            result[i][1] = store.getTenges();
        }
        return result;
    }
    
    /**
     * Metodo para ordenadar por localizacionde menor a mayor.[location,tenges]
     */
    public int[][] robots(){
        Collections.sort(robots, Comparator.comparingInt(Robot::getCurrentLocationRobot));
        int[][] result = new int[robots.size()][1];
        for (int i = 0; i < robots.size(); i++) {
            Robot robot = robots.get(i);
            result[i][0] = robot.getCurrentLocationRobot();
            
        }
        return result;
    }
    
    /**
     * Metodo para hacer visible la ruta
     */
    public void makeVisible(){
        this.isVisible = true;
        showProgressBar();
    }
    
    /**
     * Metodo para hacer invisible la ruta
     */
    public void makeInvisible(){
        this.isVisible = false;
        for (Store store : stores) {
            store.makeInvisible();
        }
        
        for (Robot robot : robots) {
            robot.makeInvisible();
        }
        
        relleno.makeInvisible();
        fondo.makeInvisible();
    }
    
    /**
     * Metodo para terminar el simulador
     */
    public void finish(){
        System.exit(0);
    }
    
    /**
     * Metodo para indicar si se logro realizar la ultima operacion.
     */
    public boolean oK(){
        return lastOperationSuccess;
    }
    
    /**
     * Espiral cuadrado
     * @param length la longitud de la ruta.
     */
    public void createSpiralRoad(int length){
        //posicion de cuadrado
        positions.clear();
        int x = 0;
        int y = 0;
        
        int stepsSide = 1;
        int squaresDrawn = 0;
        int direction  = 0;
        int currentX = centerX;
        int currentY = centerY;
        positions.put(0, new int[]{currentX, currentY});
        squaresDrawn++;
        
        while (squaresDrawn < length  ){
            for(int i = 0; i < stepsSide;i++ ){
                                
                switch (direction) {
                    case 0: x++; break; // Derecha
                    case 1: y++; break; // Abajo  
                    case 2: x--; break; // Izquierda
                    case 3: y--; break; // Arriba
                }
                
                Rectangle square = new Rectangle();
                square.changeSize(squareSize, squareSize);
                square.changeColor("magenta");

                int xPos = centerX + x * (squareSize + 10);
                int yPos = centerY + y * (squareSize + 10);
                square.moveHorizontal(xPos);
                square.moveVertical(yPos);
                square.makeVisible();
                roadSegments.add(square);
                positions.put(squaresDrawn, new int[]{xPos, yPos});
                squaresDrawn++;
            }
            
            direction = (direction + 1) % 4;
            if (direction % 2 == 0) {
                stepsSide++;
            }
        }
    }
       
    /**
     * Ganancia en forma de rectangulo
     */
    private int barraGanancia() {
        ganancias = 0;
        for (Store store : stores) {
            int storeTenges = store.getTenges();
            if (storeTenges == 0) {
                continue;
            }
            int maxBenefitForStore = 0;
             for (Robot robot : robots) {
                int distance = robot.getStartLocationRobot() - store.getLocationStore();
                int benefit = storeTenges - distance;
                // Solo considerar beneficios positivos
                if (benefit > 0 && benefit > maxBenefitForStore) {
                    maxBenefitForStore = benefit;
                }
            }
            
            // Añadir el mejor beneficio encontrado para esta tienda
            ganancias += maxBenefitForStore;
           
        }
        return ganancias;
    }
    
    /**
     * Actualiza la barra
     */
    private void barraVisual(){
        
        relleno.changeSize(50, 200);
        fondo.changeSize(40, 170);
        
        relleno.moveHorizontal(160);
        relleno.moveVertical(650);
        relleno.changeColor("black");
        
        fondo.moveHorizontal(165);
        fondo.moveVertical(655);
        fondo.changeColor("magenta");
        
        if (ganancias == 0){ 
            return;
        }
        //AIGEN 
        double porcentaje = (double) totalProfit / ganancias;
        int fillWidth = (int) (porcentaje * 100);
        fillWidth = Math.max(0, Math.min(fillWidth, 100));
        //
        if (porcentaje < 0.3) {
            fondo.changeColor("red");
        } else if (porcentaje < 0.7) {
            fondo.changeColor("yellow");
        } else {
            fondo.changeColor("green");
        }
        
        relleno.makeVisible();
        fondo.makeVisible();
    }
    
    /**
     * Muestra la barra en la parte grafica
     */
    public void showProgressBar() {
        barraGanancia();
        barraVisual();
        relleno.makeVisible();
        fondo.makeVisible();
        
    }
}

