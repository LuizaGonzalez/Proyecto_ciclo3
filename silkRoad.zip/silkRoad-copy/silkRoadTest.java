import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * The test class silkRoadTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class silkRoadTest
{
    //mini ciclo1 
    @Test
    public void shouldCreatedRoadInputMaraton()
    {
        int [][] days = {{1, 20},{2,15,15},{2,40,50},{1,50},{2,80,20},{2, 70, 30}};
        silkRoad road = new silkRoad(days);
        int[][] tiendas = road.stores();
        int[][] robots = road.robots();
        assertNotNull(road);
        assertEquals(20, robots[0][0]);
        assertEquals(50, robots[1][0]);
        assertEquals(15, tiendas[0][0]); 
        assertEquals(15, tiendas[0][1]); 
        assertEquals(40, tiendas[1][0]);   
        assertEquals(50, tiendas[1][1]); 
        assertEquals(70, tiendas[2][0]); 
        assertEquals(30, tiendas[2][1]); 
        assertEquals(80, tiendas[3][0]); 
        assertEquals(20, tiendas[3][1]);
        assertTrue(road.oK());
        
    }
    
    @Test
    public void shouldCreatedRoadEmpty()
    {
        int[][] days = {};
        silkRoad road = new silkRoad(days);
        assertNotNull("La ruta no debería ser null", road);
        int[][] robots = road.robots();
        assertEquals(0, road.profit());
        assertTrue(road.oK());
    }
    
    @Test
    public void shouldNotCreatedRoadInputInvalid()
    {
        int [][] days = {{1,20},{2, 30, 30},{3,40}};
        silkRoad road = new silkRoad(days);
        int[][] tiendas = road.stores();
        int[][] robots = road.robots();
        assertEquals(20, robots[0][0]);
        assertEquals(30, tiendas[0][0]);
        boolean robotEn40 = false;
        for (int i = 0; i < robots.length; i++) {
            if (robots[i][0] == 40) {
                robotEn40 = true;
                break;
            }
        }
        assertFalse(robotEn40);
        assertTrue(road.oK());
        
    }
    
    //mini ciclo2
    @Test
    public void shouldMoveRobotToMostProfitableStore()
    {
        silkRoad road = new silkRoad(30);
        road.placeStore(10, 30);  
        road.placeStore(20, 20); 
        road.placeRobot(15);
        
        road.moveRobots();
        int[][] robotsActuales = road.robots();
        assertEquals(10, robotsActuales[0][0]);
        assertTrue(road.oK());
    }
    
    @Test
    public void ShouldStayStillNotProfit ()
    {
        silkRoad road = new silkRoad(30);
        road.placeStore(20, 2); 
        road.placeRobot(15);
        
        road.moveRobots();
        int [][] robots  = road.robots();
        assertEquals(15, robots[0][0]);
        assertTrue(road.oK());
    }
    
    @Test 
    public void shouldNotMoveOccupiedShop()
    {
        silkRoad road = new silkRoad(30);
        road.placeStore(20, 100); 
        road.placeRobot(20);
        road.placeRobot(15);
        
        road.moveRobots();
        int [][] robots  = road.robots();
        assertEquals(15, robots[0][0]);
        assertEquals(20, robots[1][0]);
    }
    
    @Test
    public void shouldRegisterRobotExitFromStore() {
        silkRoad road = new silkRoad(50);
        road.placeStore(20, 30);
        road.placeRobot(20);   // Robot en la tienda

        road.registerRobotExit(20); // Robot sale de la tienda

        int[][] tiendas = road.emptiedStores();
        assertEquals(20, tiendas[0][0]); // ubicación de la tienda
        assertEquals(1, tiendas[0][1]);  // contador debe aumentar a 1
        assertTrue(road.oK());
    }

    @Test
    public void shouldCountMultipleExitsInSameStore() {
        silkRoad road = new silkRoad(50);
        road.placeStore(30, 40);
        road.placeRobot(30);   // Robot en la tienda

        road.registerRobotExit(30);
        road.registerRobotExit(30);
        road.registerRobotExit(30);

        int[][] tiendas = road.emptiedStores();
        assertEquals(30, tiendas[0][0]); // ubicación de la tienda
        assertEquals(3, tiendas[0][1]);  // el contador ahora es 3
        assertTrue(road.oK());
        System.out.println("El contador final de salidas de la tienda es: " + tiendas[0][1]); 
    }
    
    
    @Test
    public void shouldTrackRobotProfitsPerMove() {
        silkRoad road = new silkRoad(50);
        road.placeStore(10, 30);   // tienda con 30 monedas
        road.placeStore(20, 40);   // tienda con 40 monedas
        road.placeRobot(5);        // robot empieza en 5

        // Mover robot dos veces para que acumule ganancias
        road.moveRobots(); // debería ir a la tienda más rentable (20)
        road.moveRobots(); // después podría ir a la siguiente

        int[][] profits = road.profitPerMove();

        // Validamos que haya un registro para el robot
        assertEquals(1, profits.length);  

        // La primera columna es la posición del robot
        assertEquals(20, profits[0][0]);  

        // Las siguientes son las ganancias por movimiento
        assertTrue(profits[0][1] > 0);  
        assertTrue(profits[0][2] >= 0);  

        System.out.println("Ganancias registradas por el robot: " 
                       + profits[0][1] + ", " + profits[0][2]);
    }

}
