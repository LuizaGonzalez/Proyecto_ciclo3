import java.util.Random;
import java.util.ArrayList;
/**
 * Robots 
 * 
 * @author (Luiza Gonzalez - Camilo Leon ) 
 * @version (6 de septiembre del 2025)
 */

public class Robot{
    private String color;
    private int currentLocationRobot;
    private int startLocationRobot;
    private Rectangle cabeza;
    private Rectangle cuello;
    private Rectangle cuerpo;
    private Rectangle arms;
    private int x;
    private int y;
    private static ArrayList<String> usedColors = new ArrayList<>();
    private static final String[] availableColors = {"red", "yellow", "blue","green", "magenta", "black", "darkGray", "lightGray", "orange", "cyan"};

    private ArrayList<Integer> profitPerMove = new ArrayList<>();
    /**
     * Contructor de la clase Robot.
     * @param startLocationRobot ubicacion en X inical.
     */
        public Robot(int startLocationRobot){
        
        this.color = unicoColor();
        this.currentLocationRobot = startLocationRobot;
        this.startLocationRobot = startLocationRobot;
        this.x = 0;
        this.y = 0;
        cabeza = new Rectangle();
        arms = new Rectangle();
        cuello = new Rectangle();
        cuerpo = new Rectangle();
        
        CreateRobot(color);    
    }
    
    /**
     * Metodo construye el robot.
     * @param color color del robot a construir.
     */
    private void CreateRobot(String color){
        cabeza.changeColor(color);
        cuello.changeColor(color);
        arms.changeColor(color);
        cuerpo.changeColor(color);
        
        cabeza.changeSize(9, 9);           
        cuello.changeSize(5, 5);             
        cuerpo.changeSize(16, 16);         
        arms.changeSize(4, 27); 
        updateRobotPosition(x,y);
    }
    // Registrar la ganancia obtenida en un movimiento
    public void addProfit(int profit) {
        profitPerMove.add(profit);
    }

    // Consultar todas las ganancias por movimiento
    public ArrayList<Integer> getProfitPerMove() {
        return profitPerMove;
    }
    
    /**
     * Actualiza la posición de todas las partes del robot
     */
    private void updateRobotPosition(int newX, int newY) {
        // Calcular cuánto nos tenemos que mover desde la posición actual
        int deltaX = newX - this.x;
        int deltaY = newY - this.y;
        
        // Mover todas las partes del robot
        cabeza.moveHorizontal(deltaX);
        cabeza.moveVertical(deltaY);
        
        cuello.moveHorizontal(deltaX + 1);
        cuello.moveVertical(deltaY + 5);
        
        cuerpo.moveHorizontal(deltaX-2);
        cuerpo.moveVertical(deltaY + 5);
        
        arms.moveHorizontal(deltaX -5);
        arms.moveVertical(deltaY+8);
        
        // Actualizar la posición actual
        this.x = newX;
        this.y = newY;
    }
    
    /**
     * Metodo que hace que los robots no tengan colores repetidos.
     */
    private String unicoColor() {
        Random random = new Random();
        //AIGEN
        String selectedColor;
        do {
            int index = random.nextInt(availableColors.length);
            selectedColor = availableColors[index];
        } while (usedColors.contains(selectedColor));
        
        usedColors.add(selectedColor);
        return selectedColor;
    }
    
    /**
     * Hace invisible el robot.
     * 
    */
    public void makeInvisible(){

        cabeza.makeInvisible();
        cuello.makeInvisible();
        cuerpo.makeInvisible();
        arms.makeInvisible();
        
    }
    
     /**
     * Hace visible el robot
     * 
    */
    public void makeVisible(){
        cabeza.makeVisible();
        cuello.makeVisible();
        cuerpo.makeVisible();
        arms.makeVisible();
    }
    
    /**
     * Metodo que obtiene la posicion actual de un robot.
     */
    public int getCurrentLocationRobot() {
        return currentLocationRobot;
    }
    
    /**
     * Metodo que obtiene la posicion inicial de un robot.
     */
    public int getStartLocationRobot() {
        return startLocationRobot;
    }
    
    /**
     * Metodo que modifica la posicion actual de un robot.
     * @param currentLocationRobot posicion actual de un robot.
     */
    public void setCurrentLocationRobot(int currentLocationRobot) {
        this.currentLocationRobot = currentLocationRobot;
    }
    
    /**
     * Metodo que modifica la posicion inicial de un robot.
     * @param startLocationRobot posicion inicial de un robot.
     */
    public void setStartLocationRobot(int startLocationRobot) {
        this.startLocationRobot = startLocationRobot;
    }
    
    /**
     * Muestra el robot.
     * 
    */
    public void showRobots(){
        makeInvisible();
        makeVisible();
    }
    
    /**
     * Metodo que mueve un robot de una posicion actual a otra posicion dependiendo de lo metros.
     * @param meters metros que se va a mover el robot.
     */
    public void move(int meters) {
        int newPosition = currentLocationRobot + meters;
        
        cabeza.moveHorizontal(meters );
        cuello.moveHorizontal(meters);
        cuerpo.moveHorizontal(meters);
        arms.moveHorizontal(meters);
    
        currentLocationRobot = newPosition;
    }
    
    /**
     * Metodo ue obtiene el color de un robot.
     */
    public String getColor(){
        return color;
    }
    
    public void moveTo(int newX, int newY) {
        int centerX = newX + 15;  
        int centerY = newY + 15;

        updateRobotPosition(newX, newY);
    }
}