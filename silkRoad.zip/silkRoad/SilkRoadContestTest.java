import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/**
 * The test class SilkRoadContestTest.
 *
 * @author  (your name)
 * @version (a version number or a date)
 */
public class SilkRoadContestTest
{
    // ========== PRUEBAS PARA solve() ==========
    
    @Test
    public void shouldReturnZeroWhenNoStores() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] days = {{1, 5}, {1, 10}};
        // Debe imprimir 0, 0
        contest.solve(days);
    }
    
    @Test
    public void shouldReturnZeroWhenNoRobots() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] days = {{2, 5, 20}, {2, 10, 30}};
        // Debe imprimir 0, 0
        contest.solve(days);
    }
    
    @Test
    public void shouldNotMoveWhenProfitIsNegative() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] days = {{1, 5},{2, 100, 10}};
        // Día 2: 0 (no se mueve)
        contest.solve(days);
    }
    
    @Test
    public void shoulRespondToTheProblemEntry() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] days = {
            {1, 20},        // Día 1: Robot en posición 20
            {2, 15, 15},    // Día 2: Tienda en 15 con 15 tenges
            {2, 40, 50},    // Día 3: Tienda en 40 con 50 tenges  
            {1, 50},        // Día 4: Robot en posición 50
            {2, 80, 20},    // Día 5: Tienda en 80 con 20 tenges
            {2, 70, 30}     // Día 6: Tienda en 70 con 30 tenges
        };
        
        contest.solve(days);
    }
    
    @Test
    public void shouldAnswerTheEntryOfTheSimilarProblem() {
        SilkRoadContest contest = new SilkRoadContest();
        int[][] days = {
            {1, 10},        // Día 1: Robot en 10 → 0
            {2, 5, 25},     // Día 2: Robot10 → Tienda5: 25-5=20 → Robot queda en 5
            {2, 20, 40},    // Día 3: Robot5 → Tienda20: 40-15=25 → Total 20+25=45
            {1, 30},        // Día 4: Robots en 20 y 30 → Optimizar con tiendas 5(25),20(40)
            {2, 35, 35}     // Día 5: Robots en 20 y 30 → Optimizar con tiendas 5(25),20(40),35(35
        };
        
        contest.solve(days);
    }
    
    // ========== PRUEBAS PARA simulate() ==========
    
    /**
     * Test 1: Simular caso básico con un robot y una tienda
     * Verifica que el robot se mueve visualmente y obtiene ganancia
     */
    @Test
    public void shouldWorkMoveTheRobotTakeProfitBlink() {
        int[][] days = {{1, 0},{2, 3, 10}};
        
        int[] expectedProfits = {0, 7};
        boolean stateSlow = true;
        SilkRoadContest.simulate(days, stateSlow);
    }
    /**
     * Test 5: Simular caso sin elementos
     * Verifica que no hay errores con entrada vacía
     */
    @Test
    public void shouldWorkWithEmptyInput() {
        
        int[][] days = {};

        boolean stateSlow = false;
        SilkRoadContest.simulate(days, stateSlow);
    }
    @Test
    public void shouldWorkWithManyElements() {
        
        int[][] days = {
            {1, 0}, {1, 10}, {1, 20}, {1, 30},  // 4 robots
            {2, 5, 15}, {2, 15, 25}, {2, 25, 35}, {2, 35, 45}  // 4 tiendas
        };
    
        boolean stateSlow = true;
        SilkRoadContest.simulate(days, stateSlow);
    }
}