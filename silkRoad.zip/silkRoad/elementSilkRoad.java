import java.util.ArrayList;
import java.util.Random;
import java.awt.Color;
/**
 * clase abstarcta de los elementos que se colocaran en la ruta de seda, es decir, de los robots
 * y las tiendas.
 * @author (Luiza Gonzalez - Camilo Leon ) 
 * @version (6 de octuble del 2025)
 */
public abstract class elementSilkRoad
{
    private int x;
    private int y;
    private boolean isVisible;
    private int location;
    private String colorElement;
    private static ArrayList<String> usedColors = new ArrayList<>();
    private static final String[] AVAILABLE_COLORS = {"red", "yellow", "blue","green", "orange","pink", "cyan", "lightGray"};

    /**
     * constructor de la clase abstarcta de los elementos que se colocaran en la ruta de seda
     * @param location indica en donde se colocara en la ruta de seda el elemento
     */
    public elementSilkRoad(int location)
    {
        this.x = 0;
        this.y = 0;
        this.isVisible = false;
        this.location = location ;
        this.colorElement = UniqueColor();
    }
    /**
     * Metodo para ubicar elemento
    */
    public void moveTo(int x, int y) {
        this.x = x;
        this.y = y;
        if (isVisible) 
        {
            hideElement();
            drawElement();
        }
    }
    /**
     * Metodo que obtiene la ubicacion del elemento 
     */
    public int getLocation()
    {
        return this.location;
    }
    
    /**
     * metodo que modifica la ubicacion del elemento
     * @param location indica en donde esta el elemento en la ruta de seda.
     */
    public void setLocation(int location)
    {
        this.location = location;
    }
    
    /**
     * Hace visible el elemento
     */
    public void makeVisible() {
        this.isVisible = true;
        drawElement();
    }
    
    /**
     * Hace invisible el elemento
     */
    public void makeInvisible() {
        this.isVisible = false;
        hideElement();
    }
    
    /**
     * Asigna un color único que no haya sido usado antes
     */
    protected String UniqueColor() {
        Random random = new Random();
        String selectedColor;
        
        // Buscar un color no usado
        do {
            int index = random.nextInt(AVAILABLE_COLORS.length);
            selectedColor = AVAILABLE_COLORS[index];
        } while (usedColors.contains(selectedColor));
        
        usedColors.add(selectedColor);
        return selectedColor;
    }
    
    /**
     * Método abstracto para dibujar el elemento visualmente
     */
    protected abstract void drawElement();
    
    /**
     * Cada subclase implementa cómo ocultarse visualmente
     */
    protected abstract void hideElement();
    
    /**
     * Metodo que devuelve el color del elemento.
     * @return color color especifico de dicho elemento.
     */
    public String getColor() {
        return colorElement;
    }
    
    /**
     * Metodo que devuelve si es visible el metodo
     *@return retorna true o false segun el estado de visibilidad.
     */
    public boolean isVisible() {
        return isVisible;
    }
    
    public int getX() {
        return x;
    }
    
    public int getY() {
        return y;
    }
    
    public void setX(int x) {
        this.x = x;;
    }
    
    public void setY(int y) {
        this.y = y;;
    }
}