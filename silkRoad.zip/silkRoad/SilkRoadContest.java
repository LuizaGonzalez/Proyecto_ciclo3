import java.util.ArrayList;
import java.util.List;

/**
 * Clase para resolver el problema de la maratón ICPC 2024 - The Silk Road with Robots
 * INTERPRETACIÓN CORRECTA: Cada robot puede visitar MÚLTIPLES tiendas en un día
 * 
 * @author (Luiza Gonzalez - Camilo Leon)
 * @version (Octubre 2025)
 */
public class SilkRoadContest 
{    
    /**
     * Resuelve el problema de la maratón
     * @param days matriz donde cada fila es [tipo, posicion] o [tipo, posicion, tenges]
     *             tipo=1: robot, tipo=2: tienda
     * @return array con la máxima ganancia por cada día
     */
    public static void solve(int[][] days) {
        List<Integer> robotPositions = new ArrayList<>();
        List<int[]> storeData = new ArrayList<>(); // [position, tenges]
        int[] results = new int[days.length];
        
        for (int d = 0; d < days.length; d++) {
            int type = days[d][0];
            int position = days[d][1];
            
            if (d > 0) {
                //resupplyStores(storeData) en ningun metodo se modifica los tenges, por lo que se mantienen los originales para analizar cada caso.
                ///returnRobots(robotPositions) pero ningun metodo actualiza las posiciones por lo que siempre estara en su posicion inicial
            }
            
            // SEGUNDO: Agregar nuevo robot o tienda
            if (type == 1) {
                robotPositions.add(position);
            } else if (type == 2) {
                int tenges = days[d][2];
                storeData.add(new int[]{position, tenges});
            }
            
            // TERCERO: Calcular máxima ganancia del día
            results[d] = calculateMaxProfit(robotPositions, storeData);
            System.out.println(results[d]);
        }
    }
    
    /**
     * Calcula la máxima ganancia posible permitiendo que cada robot visite múltiples tiendas
     * @param robotPositions arreglo de las posiciones de los robots
     * @param storeData contiene la posicion de la tienda y sus respectivos tenges.
     * @return devuelve un entero que es la maxima ganancia.
     */
    private static int calculateMaxProfit(List<Integer> robotPositions, List<int[]> storeData) {
        if (robotPositions.isEmpty() || storeData.isEmpty()) {
            return 0;
        }
        
        int n = storeData.size();
        boolean[] usedStores = new boolean[n];
        
        // Probar todas las permutaciones de asignación robot→secuencia de tiendas
        return findMaxProfitVisitManyStores(0, usedStores,robotPositions, storeData);
    }
    
    /**
     * Backtracking que permite a cada robot visitar las tiendas
     * @param robotIdx índice del robot actual
     * @param usedStores tiendas ya visitadas por robots anteriores
     * @return maxima ganancia mirando las posibles combinanciones de un robot yendo a una o mas tiendas.
     */
    private static int findMaxProfitVisitManyStores(int robotIdx, boolean[] usedStores,List<Integer> robotPositions, List<int[]> storeData) {
        if (robotIdx >= robotPositions.size()) {
            return 0;
        }
        
        int robotPos = robotPositions.get(robotIdx);
        
        // Opción 1: Este robot no visita ninguna tienda
        int maxProfit = findMaxProfitVisitManyStores(robotIdx + 1, usedStores,robotPositions, storeData);
        
        // Opción 2: Este robot visita un subconjunto de tiendas disponibles
        maxProfit = Math.max(maxProfit, possibleRouteCombinations(robotIdx, robotPos, usedStores, 0,robotPositions, storeData));
        
        return maxProfit;
    }
    
    /**
     * Explora todos los subconjuntos de tiendas que puede visitar un robot
     * @param robotIdx índice del robot
     * @param currentPos posición actual del robot
     * @param usedStores tiendas ya usadas
     * @param storeIdx tienda a considerar
     * @return maxima ganancia que se obtienen al hacer las posibles combinaciones.
     */
    private static int possibleRouteCombinations(int robotIdx, int currentPos, boolean[] usedStores, int storeIdx,List<Integer> robotPositions, List<int[]> storeData) {
        // Opción de terminar la ruta de este robot aquí
        int maxProfit = findMaxProfitVisitManyStores(robotIdx + 1, usedStores, robotPositions, storeData);
        
        // Intentar visitar más tiendas
        for (int i = storeIdx; i < storeData.size(); i++) {
            if (!usedStores[i]) {
                int storePos = storeData.get(i)[0];
                int storeTenges = storeData.get(i)[1];
                int distance = Math.abs(currentPos - storePos);
                int profit = storeTenges - distance;
                
                if (profit > 0) {
                    usedStores[i] = true;
                    
                    // Profit de esta tienda + explorar más tiendas desde esta posición
                    int totalProfit = profit + possibleRouteCombinations(robotIdx, storePos, usedStores, i + 1,robotPositions, storeData);
                    
                    maxProfit = Math.max(maxProfit, totalProfit);
                    
                    usedStores[i] = false; // Backtrack
                }
            }
        }
        
        return maxProfit;
    }

     /**
     * Simula visualmente la solución del problema usando la clase silkRoad
     * @param days matriz donde cada fila es [tipo, posicion] o [tipo, posicion, tenges]
     *             tipo=1: robot, tipo=2: tienda
     * @param slow booleano que indica si la simulación debe ir lenta (true) o rápida (false)
     */
    public static void simulate(int[][] days, boolean slow) {
        int roadLength = 0;
        for (int d = 0; d < days.length; d++) {
            int position = days[d][1];
            if (position > roadLength) {
                roadLength = position;
            }
        }
        roadLength += 10;
        silkRoad simulator = new silkRoad(roadLength);
        simulator.makeVisible();
        
        int movementDelay;
        if (slow) {
            movementDelay = 800;
        } else {
            movementDelay = 200;
        }
        int dayDelay;
        if (slow) {
            dayDelay = 4000;
        } else {
            dayDelay = 500;
        }
        int placementDelay;
        if (slow) {
            placementDelay = 6000;
        } else {
            placementDelay = 500;
        }
        
        // Reiniciar el simulador para empezar desde cero
        simulator.reboot();
        
        for (int d = 0; d < days.length; d++) {

            int type = days[d][0];
            int position = days[d][1];
            
            // Reabastecer tiendas y retornar robots ANTES de agregar nuevo elemento
            if (d > 0) {
                simulator.resupplyStores();
                simulator.returnRobots();
                
                // Pequeña pausa después del reabastecimiento
                sleep(1000);
            }
            
            // Agregar nuevo robot o tienda al simulador
            if (type == 1) {
                simulator.placeRobot(position);
                sleep(placementDelay);
            } else if (type == 2) {
                int tenges = days[d][2];
                simulator.placeStore(position, tenges);
                sleep(placementDelay);
            }
            
            // Calcular y ejecutar movimientos óptimos
            simulator.moveRobots();
            
            // Pausa entre días
            sleep(dayDelay);
        }
        
        // Destacar el robot ganador al final
        simulator.highlightBestRobot();

    }
    
    /**
     * Método auxiliar para pausas controladas
     */
    //AIGEN
    private static void sleep(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}