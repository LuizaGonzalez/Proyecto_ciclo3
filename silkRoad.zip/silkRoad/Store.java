import java.util.ArrayList;
import java.util.Random;
/**
 * Tiendas para la ruta de seda
 * 
 * @author (Luiza Gonzalez - Camilo Leon ) 
 * @version (6 de septiembre del 2025)
 */
public class Store extends elementSilkRoad{

    private int tenges;
    private int currentTenges;
    private int unoccupiedShop;//lleva la cuenta de cuantas veces ha sido desocupada la tienda
    private Rectangle tienda;
    private int outshop;
    private boolean isOccupied;
    
    /**
     * Contructor de la clase Store.
     * @param LocationStore posicion en x inicial.
     * @param tenges monedas iniciales.
     */
    public Store(int LocationStore, int tenges)
    {
        super(LocationStore);
        this.tenges = tenges;
        this.currentTenges = tenges;
        this.unoccupiedShop = 0;
        this.tienda = new Rectangle();
        this.isOccupied = true;
    }
    /**
     * Metodo que crea una tienda
     */
    @Override
    protected void drawElement()
    {
        tienda.changeSize(30,20);
        tienda.moveHorizontal(getLocation());
        tienda.moveVertical(5);
        updateOccupiedStatus();
        tienda.makeVisible();
    }
    /**
     * Obtener si la tienda está ocupada
     */
    public boolean isOccupied() {
        return isOccupied;
    }
    /**
     * Actualiza el estado visual de la tienda
     */
    public void updateOccupiedStatus() {
        if (currentTenges <= 0) {
            tienda.changeColor("darkGray");
            isOccupied = false;
        } else {
            tienda.changeColor(getColor());
            isOccupied = true;
        }
    }
    /**
     * Metodo que oculta la tienda
     */
    protected void hideElement()
    {
         tienda.makeInvisible(); // no entiedno
    }
    /**
     * Metodo que marca que un robot salió de la tienda.
     */
    public void markOutShop(){
        unoccupiedShop++;
    }
    /**
     * Devuelve cuántas veces esta tienda fue desocupada.
     */
    public int contOutStore(){
        return unoccupiedShop;
    }
    //getters
    public int getTenges() {
        return tenges;
    }
    public void setTenges(int tenges) {
        this.tenges = tenges;
    }
    public int getCurrentTenges() {
        return currentTenges;
    }
     public void setCurrentTenges(int currentTenges) {
        int previousTenges = this.currentTenges;
        this.currentTenges = currentTenges;
        // Si la tienda pasó de tener tenges a estar vacía, incrementar contador
         if (previousTenges > 0 && currentTenges == 0) {
            this.unoccupiedShop++;
        }
        updateOccupiedStatus();
    }
      public int getTimesUnoccupied() {
        return unoccupiedShop;
    }
    
    /**
     * Metodo que agrega tenses al monto que va llevando
     */
    public void addTenges(int montoTenges) {
        this.currentTenges += montoTenges;
        updateOccupiedStatus();
    }
    /**
     * Metodo que se encarga de reducir los tenges necesarios en un movimiento
     * @param meters metros que se mueve el robot
     */
    public int reduceTenges(int meters) {
        int actualReduction = meters;
        currentTenges -= actualReduction;
        if (currentTenges <= 0) {
            currentTenges = 0;
            updateOccupiedStatus();
        }
        updateOccupiedStatus();
        return actualReduction;
    }
    /**
     * Metodo que ayuda a ubicar dentro del espiral la tienda
     */
    public void moveTo(int x, int y) {
        tienda.moveHorizontal(x);
        tienda.moveVertical(y);
    }
     /**
     * Reabastece la tienda a su capacidad máxima
     */
    public void resupply()
    {
        this.currentTenges = this.tenges;
        updateOccupiedStatus();
    }
    /**
     * Vacía la tienda y registra que fue desocupada
     */
    public void emptyStore() {
        this.currentTenges = 0;
        this.unoccupiedShop++;
        updateOccupiedStatus();
    }
    
    
    
    
}