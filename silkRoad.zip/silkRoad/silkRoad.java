import java.util.ArrayList;
import java.util.Arrays;
import javax.swing.JOptionPane;
import java.util.Collections;
import java.util.Comparator;
import java.awt.Color;
import java.util.HashMap;
import java.util.Scanner;
/**
 * Ruta de seda con robots y tiendas que guardan montones de tengues, 
 * en donde cada robot se mueve para recolectarlas y tener una ganancia.
 * 
 * @author (Luiza Gonzalez - Camilo Leon ) 
 * @version (6 de septiembre del 2025)
 */
public class silkRoad{
    
    private static final String[] color = {"red", "yellow", "blue", "green", "magenta", "black", "darkGray", "lightGray", "orange", "cyan"};
    private int length;
    private int StartTenges;
    private int currentTenges;
    private int meters;
    private int totalProfit;
    private boolean lastOperationSuccess;
    private boolean isVisible;
    private ArrayList<Store> stores;
    private ArrayList<Robot> robots;
    //spiral
    private int squareSize;
    private ArrayList<Rectangle> roadSegments;
    private int centerX;
    private int centerY;
    private HashMap<Integer, int[]> positions;
    
    //barra 
    private Rectangle fondo;
    private Rectangle relleno;
    private int ganancias;
    
    
    //ciclo1
    /**
     * Contructor de la clase silkBoard.
     * @param length longitud de la ruta seda.
     */
    public silkRoad(int length){
        this.length = length;
        int location = 50;
        this.StartTenges = 0;
        this.currentTenges = 0;
        this.meters = 0;
        this.totalProfit = 0;
        stores =  new ArrayList<>();
        robots = new ArrayList<>();
        this.isVisible = true;
        this.lastOperationSuccess = true;
        this.squareSize = 40;
        roadSegments = new ArrayList<Rectangle>();
        this.centerX = 300;
        this.centerY = 300;
        positions = new HashMap<>();
        createSpiralRoad(length);
        // barra
        relleno = new Rectangle();
        fondo = new Rectangle();
        setupProgressBar();
        if (isVisible) {
            showProgressBar();
        }
    }
    //ciclo2
    public silkRoad(int[][] days){
        this(calculateLength(days));
        
        for (int[] d : days){
            if (d[0] == 1){
                placeRobot(d[1]);
            }else if(d[0]==2){
                placeStore(d[1], d[2]);
            }
            lastOperationSuccess = true;
        }
    }
    /**
     * Hace parpadear al robot con mayor ganancia acumulada
     */
    public void highlightBestRobot() {
        if (robots.isEmpty()) {
            return;
        }
    
        Robot bestRobot = null;
        int maxProfit = Integer.MIN_VALUE;
    
        // Encontrar el robot con mayor ganancia
        for (Robot robot : robots) {
            if (robot.getTotalProfit() > maxProfit) {
                maxProfit = robot.getTotalProfit();
                bestRobot = robot;
            }
        }
    
        // Hacer parpadear al mejor robot
        if (bestRobot != null && maxProfit > 0) {
            bestRobot.blink();
        }
    }
    
    
    /**
     * Calcular logitud de la ruta de seda segun la ultima casa.
     * @days matriz que tiene los casos de entrada.
     * @return la logitud de la ruta de seda.
     */
    private static int calculateLength(int [][] days){
        int lastStore = 0;
        for (int[] d : days){
            int store = d[1];
            if (store > lastStore){
                lastStore = store;
            }
        }
        return lastStore + 6;
    }
    //mini-ciclo2
    /**
     * metodo que mueve todos los robots segun la ganancia maxima
     */
    public void moveRobots(){
        for (Robot robit : robots){
            moveRoboToMaxProfit(robit);
        }
    }
    
    /**
     * metodo que calcula la maxima ganancia segun sus posibles opcciones.
     */
    private void moveRoboToMaxProfit(Robot robit){
        int currentLocation = robit.getCurrentLocation();
        int bestMove = currentLocation;
        int maxProfit = calculateProfit(currentLocation,currentLocation); 
        
        for (Store store : stores) {
            int storeLocation = store.getLocation();
            int profit = calculateProfit(currentLocation, storeLocation);
            if (profit > maxProfit) {
                maxProfit = profit;
                bestMove = storeLocation;
            }
        }
        
        if (bestMove != currentLocation) {
            int metersToMove = bestMove - currentLocation;
            moveRobot(currentLocation, metersToMove);
        }
    }
    
    /**
     * Calcula la ganancia potencial de moverse de una ubicación a otra
     */
    private int calculateProfit(int currentPos, int newPos) {
        int distance = Math.abs(newPos - currentPos);
        int storeProfit = 0;
        // Verifica si hay tienda en la nueva posición
        for (Store store : stores) {
            if (store.getLocation() == newPos) {
                storeProfit = store.getCurrentTenges();
                break;
            }
        }
        
        return storeProfit - distance;
    }
    
    /**
     * Registra la ganancia de un robot al visitar una tienda.
        */
    private void registerProfit(Robot robot, Store tienda) {
        int ganancia = tienda.getCurrentTenges(); // O el valor que se recoja
        robot.addProfit(ganancia);
    }
    
    /**
     * consultar cuántas veces se vació cada tienda
     */
    public int[][] emptiedStores(){
        int[][] steam = new int[stores.size()][2];
        for(int i = 0; i < stores.size(); i++){
            Store s = stores.get(i);
            steam[i][0] = s.getLocation();
            steam[i][1] = s.contOutStore();
        }
        Arrays.sort(steam, (a, b) -> Integer.compare(a[0], b[0]));
        return steam; 
    }

    /**
     *consultar ganancias
     */
    public int[][] profitPerMove() {
        int[][] robocop = new int[robots.size()][];

        for (int i = 0; i < robots.size(); i++) {
            Robot r = robots.get(i);
            
            ArrayList<Integer> movements = r.getProfitPerMove();
            robocop[i] = new int[movements.size() + 1];
            robocop[i][0] = r.getCurrentLocation();

            // Copiamos las ganancias registradas en el robot
            for (int j = 0; j < movements.size(); j++) {
                robocop[i][j + 1] = movements.get(j);
            }
        }

        Arrays.sort(robocop, (a, b) -> Integer.compare(a[0], b[0]));

        return robocop;
    }
    //Hasta aqui ciclo2
    /**
     * Metodo para ubicar una tienda con su respectivo tenges. 
     * @param location posicion de la tienda.
     * @param tenges Son las monedas de Kazajistan.
     */
    public void placeStore(int location, int tenges){
        
        if (location < 0 || location > length){
            JOptionPane.showMessageDialog(null,"la locazion que deseas, esta por fuera del rango","Error", JOptionPane.ERROR_MESSAGE);
            lastOperationSuccess = false;
            
            if (isVisible) {
                JOptionPane.showMessageDialog(null, "Ubicación fuera de rango", "Error", JOptionPane.ERROR_MESSAGE);
            }
            return;
        }
        
        for (Store tienda : stores){
            if (tienda.getLocation() == location){
                JOptionPane.showMessageDialog(null,"Ya exixte una tienda en esta ubicacion","Error", JOptionPane.ERROR_MESSAGE);
                lastOperationSuccess = false;
                if (isVisible) {
                    JOptionPane.showMessageDialog(null, "Ubicación fuera de rango", "Error", JOptionPane.ERROR_MESSAGE);
                }
                return;
            }
        }
        
        Store newStore = new Store(location,tenges);
        stores.add(newStore);
        int[] pos = positions.get(location);
        if (pos != null){
            newStore.moveTo(pos[0],pos[1]);
        }
        calculateMaxProfit();
        if (isVisible) {
            showProgressBar();
            newStore.makeVisible();
        }
        lastOperationSuccess = true;
    }

    /**
     * Metodo para eliminar una tienda dada su posicion.
     * @param location bposicion de la tienda.
     */
    public void removeStore(int location){
        for (int i = 0; i < stores.size(); i++) {
            Store tienda = stores.get(i);
            if (tienda.getLocation() == location){
                tienda.makeInvisible();
                stores.remove(tienda);
                calculateMaxProfit();
                showProgressBar();
                lastOperationSuccess = true;
                return;
            }
        }
    }
    
    /**
     * Metodo para ubicar un robot.
     * @param location posicion del robot.
     */
    public void placeRobot(int location){
        if (location<0 || location > length){
            JOptionPane.showMessageDialog(null, "la locazion que deseas, esta por fuera del rango", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        
        for(Robot r : robots){
            if(r.getCurrentLocation()== location ){
                JOptionPane.showMessageDialog(null, "Ya exixte un robot en esta ubicacion", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
        }
        
        Robot newRobot = new Robot(location);
        robots.add(newRobot);
        int[] pos = positions.get(location);
        if (pos != null){
            newRobot.moveTo(pos[0],pos[1]);
        }
        calculateMaxProfit();
        if (isVisible) { // AGREGAR ESTA VALIDACIÓN
            showProgressBar();
        }
        calculateMaxProfit();
        showProgressBar();
        lastOperationSuccess = true;
        newRobot.makeVisible();
    }
    
    /**
     * Metodo para eliminar un robot.
     * @param location posicion del robot.
     */
    public void removeRobot(int location){
        for (Robot r : robots){
            if (r.getCurrentLocation() == location){
                r.makeInvisible();
                robots.remove(r);
                showProgressBar();
                lastOperationSuccess = true;
                return;
            }
        }
    }
    
    /**
     * Metodo para mover un robot.
     * @param location posicion del robot.
     * @param meters metros que se movera el robot.
     */
    public void moveRobot(int location, int meters){
        
        Robot robotMove = null;
        for (Robot roro : robots){
            if(roro.getCurrentLocation() == location){
                robotMove = roro;
                break;
            }
        }
        
        if (robotMove == null) {
            JOptionPane.showMessageDialog(null, "No se encontró robot en la ubicación: ","Error", JOptionPane.ERROR_MESSAGE);
            lastOperationSuccess = false;
            return;
        }
        
        int newLocation = location + meters;
            
        if (newLocation<0 ||newLocation >= length){
            JOptionPane.showMessageDialog(null,"No puedes mover el robot, ubicacion por fuera del rango","Error", JOptionPane.ERROR_MESSAGE);
            lastOperationSuccess = false;
            return;
        }
        
        for (Robot robit : robots)
        {
            if (robit != robotMove &&  newLocation == robit.getCurrentLocation())
            {
                if (isVisible) {
                    JOptionPane.showMessageDialog(null, "This location already has a robot", "Error", JOptionPane.ERROR_MESSAGE);
                    lastOperationSuccess = false;
                    return;
                }    
            }
        }
        int[] newPosition = positions.get(newLocation);
        if (newPosition != null) {
            robotMove.moveTo(newPosition[0], newPosition[1]);
            robotMove.setCurrentLocation(newLocation);
        }else {
            JOptionPane.showMessageDialog(null, "No se encontró posición para location ", "Error", JOptionPane.ERROR_MESSAGE);
            lastOperationSuccess = false;
            return;
        }
        //recolectarTENGUES
        collectVerifyRobotsStore(robotMove,newLocation);
        calculateMaxProfit();
        showProgressBar();
        lastOperationSuccess = true;
    }
    
    /**
     * Método para recolectar tenges cuando un robot llega a una tienda
     * @param robot
     * @param meters
     */
    private void collectVerifyRobotsStore(Robot robot, int newLocation)
    {
        for (Store store : stores) {
            if (store.getLocation() == newLocation) {
                int tenges = store.getCurrentTenges();
                int distanciaRecorrida = Math.abs(newLocation - robot.getLocation());
                int profit = tenges - distanciaRecorrida;
                if (profit > 0) {
                    totalProfit += profit;
                    robot.addProfit(profit);
                    store.setCurrentTenges(0); 
                }
                break;
            }
        }
    }
    
    /**
     * Metodo para reabastecer las tiendas.
     */
    public void resupplyStores(){
        if (stores.isEmpty()){
            return;
        }
        for (Store store : stores){
           store.resupply();
        }
        calculateMaxProfit();
        showProgressBar();
    }
    
    /**
     * Metodo para retornar los robots a sus posiciones iniciales.
     */
    public void returnRobots(){
       if (robots.isEmpty()){
           JOptionPane.showMessageDialog(null, "No hay robots", "Error", JOptionPane.ERROR_MESSAGE);
           lastOperationSuccess = false;
           return;
       }
       for (Robot robit : robots){
           robit.returnToStart();
           int[] startPosition = positions.get(robit.getLocation());
           if (startPosition != null) 
           {
               robit.moveTo(startPosition[0], startPosition[1]);
               //robit.setCurrentLocationRobot(startPosition);
           }
       }
       resupplyStores();
       totalProfit = 0;
       showProgressBar();
       
       lastOperationSuccess = true;
    }
    
    /**
     * Metodo para reiniciar la ruta de seda: tiendas y robots como fueron adicionados.
     * 
     */
    public void reboot(){
        
        for (Robot robot : robots) {
            int startLocation = robot.getLocation();
            int[] startPos = positions.get(startLocation);
            if (startPos != null) {
                robot.moveTo(startPos[0], startPos[1]);
                robot.setCurrentLocation(startLocation);
            }
        }
        
        for (Store store : stores) {
            store.setCurrentTenges(store.getTenges());
        }
        // ganancias
        totalProfit = 0;
        showProgressBar();
        lastOperationSuccess = true;
    }
    
    /**
     * Metodo para consultar las ganancias obtenidas.
     */
    public int profit(){
        return totalProfit - meters;
    }
    
      /**
     * Metodo para ordenar por localizacion de menor a mayor.[location,tenges]
     */
    public int[][] stores() {
        Collections.sort(stores, Comparator.comparingInt(Store::getLocation));
        int[][] result = new int[stores.size()][2];
        for (int i = 0; i < stores.size(); i++) {
            Store store = stores.get(i);
            result[i][0] = store.getLocation();
            result[i][1] = store.getTenges();
        }
        return result;
    }
    
    /**
     * Metodo para ordenadar por localizacionde menor a mayor.[location,tenges]
     */
    public int[][] robots(){
        Collections.sort(robots, Comparator.comparingInt(Robot::getCurrentLocation));
        int[][] result = new int[robots.size()][1];
        for (int i = 0; i < robots.size(); i++) {
            Robot robot = robots.get(i);
            result[i][0] = robot.getCurrentLocation();
            
        }
        return result;
    }
    
    /**
     * Metodo para hacer visible la ruta
     */
    public void makeVisible(){
        this.isVisible = true;
        for (Store store : stores) 
        {
            store.makeVisible();
        }
        for (Robot robot : robots) {
            robot.makeVisible();
        }
        showProgressBar();
    }
    
    /**
     * Metodo para hacer invisible la ruta
     */
    public void makeInvisible(){
        this.isVisible = false;
        for (Store store : stores) {
            store.updateOccupiedStatus();
            store.makeInvisible();
        }
        
        for (Robot robot : robots) {
            robot.makeInvisible();
        }
        
        relleno.makeInvisible();
        fondo.makeInvisible();
    }
    
    /**
     * Metodo para terminar el simulador
     */
    public void finish(){
        System.exit(0);
    }
    
    /**
     * Metodo para indicar si se logro realizar la ultima operacion.
     */
    public boolean oK(){
        return lastOperationSuccess;
    }
    
    /**
     * Espiral cuadrado
     * @param length la longitud de la ruta.
     */
    private void createSpiralRoad(int length){
        //posicion de cuadrado
        positions.clear();
        int x = 0;
        int y = 0;
        
        int stepsSide = 1;
        int squaresDrawn = 0;
        int direction  = 0;
        int currentX = centerX;
        int currentY = centerY;
        positions.put(0, new int[]{currentX, currentY});
        squaresDrawn++;
        
        while (squaresDrawn < length  ){
            for(int i = 0; i < stepsSide;i++ ){
                                
                switch (direction) {
                    case 0: x++; break; // Derecha
                    case 1: y++; break; // Abajo  
                    case 2: x--; break; // Izquierda
                    case 3: y--; break; // Arriba
                }
                
                Rectangle square = new Rectangle();
                square.changeSize(squareSize, squareSize);
                square.changeColor("magenta");

                int xPos = centerX + x * (squareSize + 10);
                int yPos = centerY + y * (squareSize + 10);
                square.moveHorizontal(xPos);
                square.moveVertical(yPos);
                square.makeVisible();

                roadSegments.add(square);
                positions.put(squaresDrawn, new int[]{xPos, yPos});
                squaresDrawn++;
            }
            
            direction = (direction + 1) % 4;
            if (direction % 2 == 0) {
                stepsSide++;
            }
        }
    }
    /**
     * Configura la barra de progreso 
     */
    private void setupProgressBar() {
        relleno.changeSize(50, 200);
        fondo.changeSize(40, 170);
        
        relleno.moveHorizontal(160);
        relleno.moveVertical(650);
        relleno.changeColor("black");
        
        fondo.moveHorizontal(165);
        fondo.moveVertical(655);
        fondo.changeColor("magenta");
    }   
    /**
     * Ganancia en forma de rectangulo
     */
    private int calculateMaxProfit() {
        ganancias = 0;
        for (Store store : stores) {
            int storeTenges = store.getTenges();
            if (storeTenges == 0) {
                continue;
            }
            int maxBenefitForStore = 0;
             for (Robot robot : robots) {
                int distance = Math.abs(robot.getLocation() - store.getLocation());
                int benefit = storeTenges - distance;
                // Solo considerar beneficios positivos
                if (benefit > 0 && benefit > maxBenefitForStore) {
                    maxBenefitForStore = benefit;
                }
            }
            
            // Añadir el mejor beneficio encontrado para esta tienda
            ganancias += maxBenefitForStore;
           
        }
        return ganancias;
    }
    
    /**
     * Actualiza la barra
     */
    private void updateProfitBar()
    {
        if (ganancias == 0){ 
            fondo.changeSize(0, 170);
            return;
        }
        //AIGEN 
        double porcentaje = (double) totalProfit / ganancias;
        int fillWidth = (int) (porcentaje * 100);
        fillWidth = Math.max(0, Math.min(fillWidth, 100));
        //
        fondo.changeSize(38, 185);
        if (porcentaje < 0.3) {
            fondo.changeColor("red");
        } else if (porcentaje < 0.7) {
            fondo.changeColor("yellow");
        } else {
            fondo.changeColor("green");
        }
        
        relleno.makeVisible();
        fondo.makeVisible();
    }
    
    /**
     * Muestra la barra en la parte grafica
     */
    private void showProgressBar()
    {
        calculateMaxProfit();
        updateProfitBar();
        relleno.makeVisible();
        fondo.makeVisible();
    }
    
    /**
     * Pruebas de aceptacion
     */
    public void acceptanceTests1()
    {
        makeVisible();
         // Crear algunas tiendas
        placeStore(8, 80);
        placeStore(12, 50);
        placeStore(20, 25);
        placeStore(25, 40);
        
        // Crear algunos robots
        placeRobot(2);
        placeRobot(8);
        placeRobot(20);
        
        delay(3000); 

        moveRobot(2, 15);  
        delay(3000);
        moveRobot(8, 22);  
        delay(3000);
        moveRobots(); 
        delay(3000);
        resupplyStores();
        delay(1500);
        highlightBestRobot();
        delay(3000);
        makeInvisible();
    }
    
    /**
     * Pruebas de aceptacion
     */
    public void acceptanceTests2()
    {
        int[][] basicConfig = {
        {2, 5, 30},   // Tienda en posición 5 con 30 tenges
        {1, 2},       // Robot en posición 2
        {2, 8, 50},   // Tienda en posición 8 con 50 tenges  
        {1, 6},       // Robot en posición 6
        {2, 12, 40}   // Tienda en posición 12 con 40 tenges
        };
        
        silkRoad road1 = new silkRoad(basicConfig);
        road1.makeVisible();
        delay(3000);
        
        road1.moveRobots();
        delay(3000);
        
        road1.highlightBestRobot();
        delay(2000);
        road1.makeInvisible();
    }
    
    /**
     * Método de delay para pausas entre operaciones
     * @param milliseconds tiempo de espera en milisegundos
     */
    //AIGEN
    private void delay(int milliseconds) {
        try {
            Thread.sleep(milliseconds);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }
}
