import java.util.Random;
import java.util.ArrayList;
/**
 * Representa un robot que puede desplazarse por la Ruta de la Seda y recolectar 
 * tenges en las tiendas.
 * 
 * @author (Luiza Gonzalez - Camilo Leon ) 
 * @version (6 de septiembre del 2025)
 */

public class Robot extends elementSilkRoad
{
    private int currentLocationRobot;
    private Rectangle cabeza;
    private int totalProfit;
    private Rectangle cuello;
    private Rectangle cuerpo;
    private Rectangle arms;
    private ArrayList<Integer> profitPerMove = new ArrayList<>();
    
    /**
     * Construye un nuevo robot en la ubicación inicial especificada.
     * @param startLocationRobot ubicacion en X inical.
     */
    public Robot(int startLocationRobot)
    {
        super(startLocationRobot);
        this.currentLocationRobot = startLocationRobot;
        this.totalProfit = 0;
        this.cabeza = new Rectangle();
        this.cuello = new Rectangle();
        this.cuerpo = new Rectangle();
        this.arms = new Rectangle();
        CreateRobot(getColor());

    }
    /**
     * Metodo que crea un robot con el color especificado 
     */
    private void CreateRobot(String color)
    {
        cabeza.changeColor(color);
        cuello.changeColor(color);
        cuerpo.changeColor(color);
        arms.changeColor(color);
        
        cabeza.changeSize(9, 9);           
        cuello.changeSize(5, 5);             
        cuerpo.changeSize(16, 16);         
        arms.changeSize(4, 27); 
    
        cabeza.makeInvisible();
        cuello.makeInvisible();
        cuerpo.makeInvisible();
        arms.makeInvisible();
    }
    /**
     * Metodo construye el robot.
     * @param color color del robot a construir.
     */
    @Override
    protected void drawElement()
    {
        cabeza.makeVisible();
        cuello.makeVisible(); 
        cuerpo.makeVisible();
        arms.makeVisible();
    }
    /**
     * Metodo que oculta los elementos del robot
     */
    @Override
    protected void hideElement() {
        cabeza.makeInvisible();
        cuello.makeInvisible();
        cuerpo.makeInvisible();
        arms.makeInvisible();
    }
    /**
     * Actualiza la posición de todas las partes del robot
     * @param newX posicion en x
     * @param newY posicion en y
     */
    private void updateRobotPosition(int newX, int newY) {
        // Calcular cuánto nos tenemos que mover desde la posición actual
        int deltaX = newX - getX();
        int deltaY = newY - getY();
        
        // Mover todas las partes del robot
        cabeza.moveHorizontal(deltaX);
        cabeza.moveVertical(deltaY);
        
        cuello.moveHorizontal(deltaX + 1);
        cuello.moveVertical(deltaY + 5);
        
        cuerpo.moveHorizontal(deltaX-2);
        cuerpo.moveVertical(deltaY + 5);
        
        arms.moveHorizontal(deltaX -5);
        arms.moveVertical(deltaY+8);
        
        setX(newX);
        setY(newY);
    }
    /**
     * Registrar la ganancia obtenida en un movimiento
     * @param profit ganancia de ese movimiento
     */
    public void addProfit(int profit) {
        profitPerMove.add(profit);
        totalProfit += profit;
    }
    /**
     * Consultar todas las ganancias por movimiento
     */
    public ArrayList<Integer> getProfitPerMove() {
        return profitPerMove;
    }
    /**
    *Obtener ganancia total del robot
     */
    public int getTotalProfit() {
        return totalProfit;
    }
    /**
     * Metodo que obtiene la posicion actual de un robot.
     */
    public int getCurrentLocation() {
        return currentLocationRobot;
    }
    /**
     * Metodo que modifica la posicion actual de un robot.
     * @param currentLocationRobot posicion actual de un robot.
     */
    public void setCurrentLocation(int currentLocationRobot) {
        this.currentLocationRobot = currentLocationRobot;
    } 
    /**
     * Muestra el robot.
     * 
    */
    public void showRobots(){
        makeInvisible();
        makeVisible();
    }
    /**
     *Hacer parpadear el robot (3 veces)
     */
    public void blink() {
        for (int i = 0; i < 3; i++) {
            hideElement();
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            drawElement();
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
    
    /**
     * Metodo para actualizar la posicion de un robot
     * @newX nueva posicion en x
     * @newY nueva posicion en y
     */
    public void moveTo(int newX, int newY) {
        updateRobotPosition(newX, newY);
    }
    /**
     * Metodo que devuelve el robot a su posicion inicial
     */
    public void returnToStart() {
        this.currentLocationRobot = getLocation();
        this.totalProfit = 0; //Resetear ganancia
        this.profitPerMove.clear();
    }
}